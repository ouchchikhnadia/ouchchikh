#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include<windows.h>
#include <conio.h>
#include <unistd.h>
//Ouchchikh Nadia
//G4a
//smi4
//20-57860008

	 typedef struct date
{
int j;
int m;
int a;
}date;

typedef struct Voiture
{
int idVoiture;
char marque[15];
char nomVoiture[15];
char couleur[7];
int nbplaces;
int prixJour;
char EnLocation[4];
}voiture;

typedef struct contratLocation
{
int numContrat;
int idVoiture;
int idClient;
date debut;
date fin;
int count;
}contrat;

typedef struct Client
{
int idClient;
char nom[20];
char prenom[20];
int cin;
char adresse[15];
int telephone;
}client;


//declaration de type struct
voiture car;
contrat con;
client C;
FILE *p;
FILE *f;
FILE*h;
FILE *g;
FILE *k;
FILE*p1;

//MENU
void MenuP();
void MenuGV();
void MenuGC();
void MenuL();
//fonctions client
 void listc();
 void supc();
 void modc();
void ajoutc();
int rechC();


 //fonctions voiture
 void  listv();
 void  ajoutv();
 void SupV();
int rechV();
void modV();
//fonction contrat
void louer();
void ajoutecon();
void Visc();
void Suppc();
void Modic();
 void Retourner();
 int main()
	{
	    MenuP();
	    return 0;
	}

void MenuP(void)
{  system("cls");

	printf("\n                               \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf");
	printf("\n                               \xb3 Menu Principale \xb3");
	printf("\n                               \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9");

	printf("\n\n");

	printf("\n               \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
	printf("\n               \xba                                              \xba");
	printf("\n               \xba    Location..............................1   \xba");
	printf("\n               \xba    Gestion voitures......................2   \xba");
	printf("\n               \xba    Gestion clients.......................3   \xba");
	printf("\n               \xba    Quitter...............................4   \xba");
	printf("\n               \xba                                              \xba");
	printf("\n               \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
	printf("\n\n                                Votre choix  :  ");

 switch(getch())
{
     case '1':
         MenuL();
             break;
     case '2':
          MenuGV();
             break;
     case '3':
         MenuGC();
             break;
     case '4':{
	 system("cls");
             exit(0);}
     default:{
          printf(" \nchoix invalide");
                 sleep(2);
                 system("cls");
                    MenuP();
             }
}
 }

        void MenuGV()
{
    system("cls");

	printf("\n                               \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf");
	printf("\n                               \xb3 Gestion voiture \xb3");
	printf("\n                               \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9");

	printf("\n\n");

	printf("\n               \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
	printf("\n               \xba                                              \xba");
	printf("\n               \xba    liste de voiture......................1   \xba");
	printf("\n               \xba    Ajouter voiture.......................2   \xba");
	printf("\n               \xba    Modifier voiture......................3   \xba");
	printf("\n               \xba    Supprimer voiture.....................4   \xba");
	printf("\n               \xba    Retour................................5   \xba");
	printf("\n               \xba                                              \xba");
	printf("\n               \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
	printf("\n\n                                Votre choix  :  ");

	 switch(getch())
{
     case '1':
          listv();
             break;
     case '2':
          ajoutv();
             break;
     case '3':
          modV();
             break;
     case '4':
         SupV();
             break;
     case '5':
            MenuP();
             break;
     default:{

      printf("\n-Choix invalide");
                   sleep(2);
                   system("cls");
                    MenuGV();
             }	}

}





int rechV(int idV)
{


while(fread(&car,sizeof(car),1,p)==1)
if(car.idVoiture==idV)
return 1;
return 0;

}



void listv(void){
       system("cls");

      printf("\n\n********************************* Liste de voitures*****************************\n\n");

      p=fopen("voiture.dat","rb+");

    if(p==NULL){
    printf("Error dans l 'ouverture de fichier");
    exit(-1);
    }

       while(fread(&car,sizeof(car),1,p)>0)
		{
			printf("Id de voiture       :%d\nMarque              :%s\nNom                 :%s\nCouleur             :%s\nLe prix de jour     :%dDH\nLe nombre deplaces  :%d\nEn location         :%s\n",car.idVoiture,car.marque,car.nomVoiture,car.couleur,car.prixJour,car.nbplaces,car.EnLocation);
			printf("---------------------------------------------------------------------------------\n");
            }
			  fclose(p);
               printf("-Vous voulez retouner  (o/n)?");
            if(getch()=='o'||getch()=='O')
             MenuGV();
}




void  ajoutv(){
system("cls");

 int idV;
   printf("->Entrez id de voiture qui vous voulez ajouter   :");
   scanf("%d",&idV);
    p=fopen("voiture.dat","ab+");
    if(p==NULL){
    printf("error dans l 'ouverture de fichier");
    exit(-1);}
	if(rechV(idV) == 0)
{                    car.idVoiture=idV;
	            	printf("-Entrez  nom de voiture          :");
		             scanf("%s",car.nomVoiture);
		             fflush(stdin);
                    printf("-Entrez marque de voiture        :");
                     scanf("%s",car.marque);
                       fflush(stdin);
                    printf("-Entrez couleur de voiture       :");
                     scanf("%s",car.couleur);
                       fflush(stdin);
                    printf("-Entrez nombre place de voiture  :");
                     scanf("%d",&car.nbplaces);
                       fflush(stdin);
                    printf("-Entrez le   prix de jour        :");
                     scanf("%d",&car.prixJour);
                       fflush(stdin);
                    printf("-En location oui /non            ?");
                     scanf("%s",car.EnLocation);
                       fflush(stdin);
	                 fwrite(&car,sizeof(car),1,p);
	                  fseek(p,0,SEEK_END);
                      fclose(p);

	}
	else{
         printf("-Id du voiture deja existe \n");
	}
	 printf("-Vous voulez continuer (o/n)?");

         if(getch()=='o'||getch()=='O')
                      ajoutv();
                      else
                     {

          MenuGV();}
	}



void modV(void)
	{
		system("cls");
		int idV;
			printf("-Entrez le id  de voiture qui  vous voulez  modifier:");
			scanf("%d",&idV);
			p=fopen("voiture.dat","rb+");
               if(p==NULL){
    printf("error dans l 'ouverture de fichier");
    exit(-1);}
             while(fread(&car,sizeof(car),1,p)==1)
                {
	 	        if(rechV(idV)==1)
            {
					car.idVoiture=idV;
					printf("- Nom de voiture        :");
		             scanf("%s",car.nomVoiture);
		             fflush(stdin);
                    printf("- Marque de voiture     :");
                     scanf("%s",car.marque);
                       fflush(stdin);
                    printf("- Couleur de voiture    :");
                     scanf("%s",car.couleur);
                       fflush(stdin);
                    printf("- Nombre des places     :");
                     scanf("%d",&car.nbplaces);
                       fflush(stdin);
                    printf("- Prix de jour          :");
                     scanf("%d",&car.prixJour);
                       fflush(stdin);
                    printf("- En location oui /non  ?");
                     scanf("%s",car.EnLocation);
                    fflush(stdin);
                      fseek(p,ftell(p)-sizeof(car),0);
                      fwrite(&car,sizeof(car),1,p);
                       fclose(p);



                                     }

               else
					printf("-Id n'existe pas\n");
        }
                printf("-Vous voulez continuer (o/n)?");
                      if(getch()=='o'||getch()=='O')
                      modV();
                      else

                 MenuGV();
        }

void SupV()
{
    system("cls");
	int idV;
	 printf("-Entrez id de voiture qui vous voulez supprimer:");
	  scanf("%d",&idV);
	   fflush(stdin);

	        p=fopen("voiture.dat","rb+");
	        if(p==NULL){
    printf("error dans l 'ouverture de fichier");
    exit(-1);}
	 	        if(rechV(idV)==1)
            {
                              f=fopen("voiture1.dat","wb+");
                              if(f==NULL){
    printf("error dans l 'ouverture de fichier");
    exit(-1);}
                                   rewind(p);
                                  while(fread(&car,sizeof(car),1,p)==1){
                                         if(idV!=car.idVoiture){
                                          fseek(f,0,SEEK_CUR);
                                         fwrite(&car,sizeof(car),1,f);
                                     }}
                                          fclose(f);
                                          fclose(p);
                                           remove("voiture.dat");
                                         rename("voiture1.dat","voiture.dat");

	 		printf("-La suppression ce fait avec succee \n");

	 		 }
	 		 else{
	           	printf("-Id de  voiture n'existe pas\n");
              }
 printf("-Vous voulez continuer (o/n)?");
                      if(getch()=='o'||getch()=='O')
                      SupV();
                      else
                      {
MenuGV();
}}




void MenuGC(void)
{
	system("cls");

	printf("\n                               \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf");
	printf("\n                               \xb3 Gestion client  \xb3");
	printf("\n                               \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9");


	printf("\n\n");

	printf("\n               \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
	printf("\n               \xba                                              \xba");
	printf("\n               \xba    Liste client..........................1   \xba");
	printf("\n               \xba    Ajoute client.........................2   \xba");
	printf("\n               \xba    Modifier client ......................3   \xba");
	printf("\n               \xba    Supprimer client  ....................4   \xba");
	printf("\n               \xba    Retour................................5   \xba");
	printf("\n               \xba                                              \xba");
	printf("\n               \xba                                              \xba");
	printf("\n               \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
	printf("\n\n                                Votre choix  :  ");


  switch(getch())
{
     case '1':
         listc();
             break;
     case '2':
          ajoutc();

             break;
     case '3':
         modc();

             break;
     case '4':
          supc();
             break;
     case '5':
            MenuP();
             break;
     default:{
          printf("\n-Le choix invalide   ");
          sleep(2);

             MenuGC();
             }
}
}



        int rechC( int idC)
{

while(fread(&C,sizeof(C),1,h)==1)
if(C.idClient==idC)
return 1;
return 0;

}


void listc(void)
{
    system("cls");

      printf("\n********************************* Liste de clients*****************************\n");
	  h=fopen("client.dat","rb+");
	 if(h==NULL){
    printf("error dans l 'ouverture de fichier");
    exit(-1);}
       while(fread(&C,sizeof(C),1,h)==1)
		{
			  printf("id de client :%d\nNom          :%s\nPrenom       :%s\nCIN          :%d\nAdresse      :%s\nTelphone     :%d\n",C.idClient,C.nom,C.prenom,C.cin,C.adresse,C.telephone);
			  printf("----------------------------------------------------------------------\n");
			  }

			  fclose(h);
            printf("-Vous voulez retouner  (o/n)?");
            if(getch()=='o'||getch()=='O')
             MenuGC();
}



void  ajoutc(void){
system("cls");
 int idC;
   printf("Entrez le id de client  :");
   scanf("%d",&idC);
    fflush(stdin);
    h=fopen("client.dat","ab+");
  if(h==NULL){
    printf("error dans l 'ouverture de fichier");
    exit(-1);}
	if(rechC(idC) == 0)

       {
                    C.idClient=idC;
		             printf("-> Entrez le nom de client                 :");
                     scanf("%s",C.nom);
                      fflush(stdin);

                     printf("-> Entrez le prenom de client              :");
                     scanf("%s",C.prenom);
                      fflush(stdin);

                     printf("-> Entrez  le cin de client                :");
                     scanf("%d",&C.cin);
                      fflush(stdin);

                     printf("-> Entez l'adresse de client               :");
                     scanf("%s",C.adresse);
                      fflush(stdin);

                     printf("-> Entrez le numero de telephone de client :");
                     scanf("%d",&C.telephone);
                     fflush(stdin);
                fwrite(&C,sizeof(C),1,h);
	            fseek(h,0,SEEK_END);
              fclose(h);



	}
	else  printf("-Id de client deja existe\n");
	printf("-Vous voulez continuer (o/n)?");
                      if(getch()=='o'||getch()=='O')
                      ajoutc();
                      else{

                      MenuGC();}
	}

void modc()
	{
		system("cls");
		int idC;
			printf("-Entrez le id  de client qui vous voulez modifier:");
			scanf("%d",&idC);
			 fflush(stdin);
			h=fopen("client.dat","rb+");
			if(h==NULL){
    printf("error dans l 'ouverture de fichier");
    exit(-1);}
	while  (fread(&C,sizeof(C),1,h)  )
        {

		  if((rechC(idC)==1))
                   {
                     C.idClient=idC;
		             printf("-> Entrez le nom de client                 :");
                     scanf("%s",C.nom);
                      fflush(stdin);

                     printf("-> Entrez le prenom de client              :");
                     scanf("%s",C.prenom);
                      fflush(stdin);

                     printf("-> Entrez  le cin de client                :");
                     scanf("%d",&C.cin);
                      fflush(stdin);

                     printf("-> Entez l'adresse de client               :");
                     scanf("%s",C.adresse);
                      fflush(stdin);

                     printf("-> Entrez le numero de telephone de client :");
                     scanf("%d",&C.telephone);

                    printf("-La modification ce fait avec succee\n");
					fseek(h,ftell(h)-sizeof(C),0);
					fwrite(&C,sizeof(C),1,h);

                    }
                     else
                   printf("-Id n'existe pas\n");
                   fclose(h);
        }
   printf("-Vous voulez continuer (o/n)?");
                      if(getch()=='o'||getch()=='O')
                      modc();
                      else
                      MenuGC();
   }





void supc()
{

	system("cls");
	int idC;
	 printf("-Saisir id de voiture qui vous voulez supprimer         :");
	  scanf("%d",&idC);
	   fflush(stdin);
	   if(h==NULL){
    printf("error dans l 'ouverture de fichier");
    exit(-1);}
	        h =fopen("client.dat","rb+");
	 	          if(rechC(idC)==1)
                            {
                                rewind(h);
                                 k=fopen("client1.dat","wb+");
                                 if(k==NULL){
    printf("error dans l 'ouverture de fichier");
    exit(-1);}
                                  while(fread(&C,sizeof(client),1,h)==1){
                                         if(idC!=C.idClient){
                                        fseek(k,0,SEEK_CUR);
                                         fwrite(&C,sizeof(client),1,k);
                                     }                            }
                                          fclose(k);
                                          fclose(h);
                                           remove("client.dat");
                               rename("client1.dat","client.dat");

	 		printf("-La suppression ce fait avec succee \n");

	 		 }
	 		 else{
	           	printf("ce id  voiture n'existe pas \n");
			  }


printf("-Vous voulez continuer (o/n)?");
                      if(getch()=='o'||getch()=='O')
                      supc();
                      else
                      MenuGC();

}




void MenuL()
{
	system("cls");


	printf("\n                               \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf");
	printf("\n                               \xb3 Location voiture\xb3");
	printf("\n                               \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9");

	printf("\n\n");

	printf("\n               \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
	printf("\n               \xba                                              \xba");
	printf("\n               \xba    Visualiser contrat....................1   \xba");
	printf("\n               \xba    louer voiture.........................2   \xba");
	printf("\n               \xba    Retourner voiture.....................3   \xba");
	printf("\n               \xba    Modifier contrat......................4   \xba");
	printf("\n               \xba    Supprimer contrat.....................5   \xba");
	printf("\n               \xba    Retour................................6   \xba");
	printf("\n               \xba                                              \xba");
	printf("\n               \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
	printf("\n\n                                Votre choix  :  ");

switch(getch())
{
     case '1':
         Visc();
             break;
     case '2':
          louer();
             break;
     case '3':
        Retourner();
             break;
     case '4':
         Modic();
             break;
     case '5':
        Suppc();
             break;
     case '6':
         MenuP();
             break;
     default:{

          printf("\nLe choix invalide");
          sleep(2);

          MenuL();
             }
}
}

int rechCo(int num)
{



while(fread(&con,sizeof(con),1,g)==1)
if(con.numContrat==num)
return 1;
return 0;

}

void Visc(){
    system("cls");
    int num;
      printf("\n\n********************************* Liste de contrat*****************************\n\n");
      printf("-Entrez le numero de contrat :");
      scanf("%d",&num);
	  g=fopen("contrat.dat","rb+");
	  if(g==NULL){
    printf("error dans l 'ouverture de fichier");
    exit(-1);}
		    if(rechCo(num)==1)
		    {

			printf("->Id de voiture       :  %d\n",con.idVoiture);

			printf("->Id de client        :   %d\n",con.idClient);

			printf("->Le debut de la date :  %d/%d/%d \n",con.debut.j,con.debut.m,con.debut.a );

			printf("->La fin de la date   :   %d/%d/%d \n",con.fin.j,con.fin.m,con.fin.a);

			printf("->Le prix             : %d dh         \n",con.count);

         }

        else printf("-le contrat n'exist pas\n");

        fclose(g);
        printf("-Vous voulez contenuer  (o/n)?");
            if(getch()=='o'||getch()=='O')

        MenuL();

}

 void Retourner(void)
 {
  system("cls");
    int id;
   int t=0;
	 	printf("=> Entrer l'id de voiture a retourner : ");
	 	scanf("%d",&id);
    p=fopen("voiture.dat","rb+");
    if(g==NULL){
    printf("error dans l 'ouverture de fichier");
    exit(-1);}
	 	if( rechV(id)==1){

	 		    fseek( p,0, SEEK_SET );
               do{
                     fread( &car , sizeof(struct Voiture) , 1 , p);
              t++;
               }while(car.idVoiture!=id);
                      fseek( p, (t-1)* sizeof(struct Voiture) , SEEK_SET );
                      fread( &car , sizeof(struct Voiture) , 1 , p);
                       strcpy(car.EnLocation,"non");
                    fseek( p ,(t-1)*sizeof(struct Voiture) , SEEK_SET );
                    fwrite( &car , sizeof(struct Voiture) , 1 , p );
                    fclose(p);
                    Suppc();

	 	}
      else
        printf("-Cette voiture n'est pas enregistrer\n");

       printf("-Vous voulez continuer (o/n)?");
                      if(getch()=='o'||getch()=='O')
                      Retourner();
                      else
                      MenuL();


 }
void louer(void)
{
    system("cls");
int idV;
char nom[15],pr[15];
int t=0;
p=fopen("voiture.dat","rb+");
if(p==NULL){
    printf("error dans l 'ouverture de fichier");
    exit(-1);}
h=fopen("client.dat","rb+");
if(h==NULL){
    printf("error dans l 'ouverture de fichier");
    exit(-1);}

g=fopen("contrat.dat","ab+");
if(g==NULL){
    printf("error dans l 'ouverture de fichier");
     exit(-1);}
if(h!=0){
 printf("-Saisir votre nom   : ");
 scanf("%s",nom);
 printf("-Saisir votre prenom: ");
 scanf("%s",pr);}

while(fread(&C,sizeof(struct Client),1,h)==1){

    if(strcmp(C.prenom,pr)==0 &&strcmp(C.nom,nom)==0 ){
        t=1;
    }
}
if(t==1){
    printf("%s  %s se trouve dans la liste des client  :\n",nom,pr);
printf("-Saisir id de voiture que vous voulez   louer : ");
scanf("%d",&idV);
fflush(stdin);
rewind(p);
while(fread(&car,sizeof(struct Voiture),1,p)==1){
    if(car.idVoiture!=idV  || strcmp(car.EnLocation,"oui")==0){
        printf("-Cette voiture n'est pas disponible\n");

    }else{
        printf("-La voiture est disponible.\n");
    printf("-Vous voulez louer la voiture (o/n)?");
    if(getch()=='o'||getch()=='O'){
    int v=0;
     v= rechV(idV);
        fseek( p, v* sizeof(struct Voiture) , SEEK_SET );
       fread( &car , sizeof(struct Voiture) , 1 , p);
         strcpy(car.EnLocation,"oui");
        fseek( p ,-sizeof(struct Voiture) , SEEK_CUR );
       fwrite( &car , sizeof(struct Voiture) , 1 , p );
       fclose(p);
      ajoutecon();
   fwrite(&con,sizeof(con),1,g);
    }
   fclose(g);
}
}
}
else
{
    printf("-%s %s ne trouve pas dans la liste des client:\n",pr,nom);
}


                      MenuL();
}


void  ajoutecon(){
system("cls");
g=fopen("contrat.dat","ab+");
if(g==NULL){
    printf("error dans l 'ouverture de fichier");
    exit(-1);}

                    printf("-Entrez le numero de contrat vous voulez ajouter  :");
                     scanf("%d",&con.numContrat);
		             fflush(stdin);
		            printf("-Entrez le id de voiture                          :");
                     scanf("%d",&con.idVoiture);
                       fflush(stdin);
                    printf("-Entrez le id de client                           :");
                     scanf("%d",&con.idClient);
                       fflush(stdin);
                    printf("-Entrez le debut de date jour/mois/annee          :");
                     scanf("%d%d%d",&con.debut.j,&con.debut.m,&con.debut.a);
                       fflush(stdin);
                    printf("-Entrez fin de date jour/mois/annee                :");
                       scanf("%d%d%d",&con.fin.j,&con.fin.m,&con.fin.a);
                           fflush(stdin);
                    printf("-Entrer le count                                   :");
                     scanf("%d",&con.count);
	        fwrite(&con,sizeof(con),1,g);
	        fseek(g,0,SEEK_END);
              fclose(g);




         MenuL();
}





void Modic(void)
	{
		system("cls");

		int num;
			printf("-Entrez le numero de contrat qui vous modifier:");
			scanf("%d",&num);
			g=fopen("contrat.dat","rb+");
			if(g==NULL){
    printf("error dans l 'ouverture de fichier ");
    exit(-1);}
	while  (fread(&con,sizeof(con),1,g)  )
        {

		  if(rechCo(num)==1)
{
                     printf("Entrez debut de date jour/mois/annee  :");
                     scanf("%d%d%d",&con.debut.j,&con.debut.m,&con.debut.a);
                     fflush(stdin);
                     printf("-Entrez fin de date jour/mois/annee   :");
                     scanf("%d%d%d",&con.fin.j,&con.fin.m,&con.fin.a);
                     fflush(stdin);
                     printf("-Entrer le count                       :");
                     scanf("%d",&con.count);
					printf("la modification ce fait avec succee");
					fseek(g,ftell(g)-sizeof(con),0);
					fwrite(&con,sizeof(con),1,g);
					fclose(g);

}
                   else
					printf("-Ce id n'existe pas");


        }
        printf("-Vous voulez continuer (o/n)?");
                      if(getch()=='o'||getch()=='O')
                      Modic();
                      else
                      MenuL();
	}

void Suppc()
{
    system("cls");
	int num;
	 printf("-Entrez nemuro de contrat qui vous voulez supprimer :");
	  scanf("%d",&num);
	   fflush(stdin);
	        g=fopen("contrat.dat","rb+");
	        if(g==NULL){
    printf("error dans l 'ouverture de fichier");
    exit(-1);}
	 	        if(rechCo(num)==1)
            {
                              p1=fopen("contrat1.dat","wb+");
                              if(p1==NULL){
    printf("error dans l 'ouverture de fichier");
    exit(-1);}
                                   rewind(g);
                                  while(fread(&con,sizeof(con),1,g)==1){
                                         if(num!=con.numContrat){
                                        fseek(p1,0,SEEK_CUR);
                                         fwrite(&con,sizeof(con),1,p1);
                                     }                            }
                                          fclose(p1);
                                          fclose(g);
                                           remove("contrat.dat");
                               rename("contrat1.dat","contrat.dat");

	 		printf("-La suppression ce fait avec succee      \n");

	 		 }
	 		 else{
	           	printf("-Ce numero de contrat n'existe pas\n");
              }

printf("-Vous voulez continuer (o/n)?  ");
                      if(getch()=='o'||getch()=='O')
                      Suppc();
                      else
                      MenuL();
}





